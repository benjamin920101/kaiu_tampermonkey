// ==UserScript==
// @name                 Font substitution: Sarasa Gothic
// @name:zh-CN           標楷體
// @name:zh-TW           標楷體
// @name:zh-HK           標楷體
// @name:ja              フォント置換：更紗ゴシック
// @name:ko              글꼴 대체：사라사고딕
// @namespace            https://gist.github.com/zozovo/8a76915acf197a873304dd23f2cfd49c
// @version              5.9
// @author               zozovo
// @description          Substitute fonts with Sarasa Gothic CJK and Sarasa Mono.
// @description:zh-CN    標楷體。
// @description:zh-TW    標楷體。
// @description:zh-HK    標楷體。
// @description:ja       フォントを 更紗ゴシック（CJK） および 更紗ゴシック Mono に 置き換えます。
// @description:ko       글꼴을 사라사고딕 CJK 및 사라사고딕 Mono 교체합니다.
// @match                *://*/*
// @run-at               document-body
// @grant                GM_addStyle
// @grant                GM_registerMenuCommand
// @grant                GM_unregisterMenuCommand
// @license              MIT
// ==/UserScript==

GM_unregisterMenuCommand((GM_registerMenuCommand("Fonts selection", () => alert("WIP"))));
GM_addStyle(`
@font-face { font-family: DFKai-SB; src: url('https://raw.githubusercontent.com/peter279k/publisher-system/master/fonts/kaiu.ttf'); }
@font-face { font-family: DFKai-SB_EmbeddedFont; src: url('https://raw.githubusercontent.com/peter279k/publisher-system/master/fonts/kaiu.ttf'); }
@font-face { font-family: DFKai-SB_MSFontService; src: url('https://raw.githubusercontent.com/peter279k/publisher-system/master/fonts/kaiu.ttf'); }
`);